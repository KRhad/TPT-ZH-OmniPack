# 模组提取报告

```text
repositories_discovered=41
repositories_cloned=27
raw_sources_downloaded=2
repositories_buildable=not_tested
mods_cataloged=41
mods_with_source=28
mods_binary_only=1
mods_license_compatible=20
mods_license_unknown=20
cpp_elements_detected=4248
lua_elements_detected=277
candidate_definition_records=4522
unique_candidate_elements=563
licensed_source_candidates=554
duplicate_candidates=239
duplicate_definition_records=3860
canonical_merge_review_candidates=227
rejected_candidates=0
direct_port_candidates=1
rewrite_candidates=553
reference_only_candidates=248
elements_ported=0
elements_rewritten=4
elements_rejected=0
periodic_source_map_complete=true
periodic_elements_sourced=118
periodic_elements_remaining=0
periodic_noble_gas_batch_complete=true
periodic_alkali_batch_complete=true
periodic_alkaline_earth_batch_complete=true
periodic_boron_group_batch_complete=true
periodic_carbon_group_batch_complete=true
periodic_nitrogen_group_batch_complete=true
periodic_oxygen_group_batch_complete=true
periodic_halogen_group_batch_complete=true
periodic_first_transition_batch_complete=true
periodic_second_transition_batch_complete=true
periodic_third_transition_batch_complete=true
periodic_lanthanide_batch_complete=true
periodic_actinide_batch_complete=true
periodic_superheavy_batch_complete=true
periodic_table_ui=true
total_omnipack_elements=293
compatibility_aliases=1
total_omnipack_playable=292
active_non_alias_types=487
directly_selectable_materials=466
total_playable_materials=466
inorganic_batch1_elements=16
inorganic_batch2_elements=16
inorganic_batch3_elements=18
engineering_alloys_batch1_elements=9
materials_batch1_elements=12
isotope_batch1_elements=13
organic_batch1_elements=13
organic_batch2_elements=20
electronics_batch1_elements=20
environment_batch1_elements=16
reaction_registry_entries=328
clean_build_pass=true
element_registry_pass=true
reaction_registry_pass=true
license_audit_pass=true
first_port_batch_complete=false
first_port_batch_build_pass=not_tested
first_port_batch_tests_pass=not_tested
```

数值只代表当前克隆集和自动扫描。候选数按标准化名称与代号折叠重复分叉；行为差异仍保留在去重报告中。
`duplicate_definition_records` 是自动归入同概念比较的全部源码定义数，包含待主元素增量审计的记录，不等于已经人工拒绝的独立材料。`canonical_merge_review_candidates` 进入 `B_rewrite_port`，目标是合并主元素而不是新增 ID。
`license_audit_pass=true` 只能由完成逐文件、README、子模块和资源复核后的显式参数写入。
当前新增 92 个周期元素、无机三批 50 个材料、工程材料、代表性核素、有机/聚合物、电子材料以及生态与污染首批中的 14 个材料均为 OmniPack 原创族/反应逻辑，不计入第三方 `elements_ported` 或 `elements_rewritten`。`ACET=595`、`UREA=600`、`SOIL=670` 与 `BLOD=679` 保留兼容 GPL 来源的概念和文件级追踪，当前更新函数均按本项目架构重写，因此保守计为 `elements_rewritten=4`；第三方更新函数逐行复制仍为 0。`first_port_batch_complete=false` 仍是许可证门禁的真实结果，不能把原创内容或 4 个重写项冒充成已完成 50 元素移植。
`OMNI_PT_MSCR=278` 是合并到官方 `DEFAULT_PT_BRMT=30` 的兼容别名；它继续占用稳定槽以读取旧存档，但不计入 `total_omnipack_playable`、`active_non_alias_types` 或 `total_playable_materials`。`total_playable_materials` 只统计普通菜单可直接选择的真实材料，不包含擦除工具和官方隐藏过渡/辅助类型。
